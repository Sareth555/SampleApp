**To delete a user pool client**

This example deletes a user pool client.

Command::

  aws cognito-idp delete-user-pool-client --user-pool-id us-west-2_aaaaaaaaa --client-id 38fjsnc484p94kpqsnet7mpld0

