**To confirm a forgotten password**

This example confirms a forgotten password for username diego@example.com. 

Command::

  aws cognito-idp confirm-forgot-password --client-id 3n4b5urk1ft4fl3mg5e62d9ado --username=diego@example.com --password PASSWORD --confirmation-code CONF_CODE
  
