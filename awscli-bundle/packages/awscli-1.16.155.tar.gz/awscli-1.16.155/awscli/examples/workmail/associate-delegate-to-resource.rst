**To add a delegate to a resource**

This example adds a delegate to a resource.

Command::

  aws workmail associate-delegate-to-resource --organization-id m-d281d0a2fd824be5b6cd3d3ce909fd27 --resource-id r-68bf2d3b1c0244aab7264c24b9217443 --entity-id S-1-1-11-1111111111-2222222222-3333333333-3333

Output::

  None